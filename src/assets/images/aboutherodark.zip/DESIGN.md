---
name: San Isidro Civic Design System
colors:
  surface: '#f8f9fa'
  surface-dim: '#d9dadb'
  surface-bright: '#f8f9fa'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f3f4f5'
  surface-container: '#edeeef'
  surface-container-high: '#e7e8e9'
  surface-container-highest: '#e1e3e4'
  on-surface: '#191c1d'
  on-surface-variant: '#414753'
  inverse-surface: '#2e3132'
  inverse-on-surface: '#f0f1f2'
  outline: '#727784'
  outline-variant: '#c1c6d5'
  surface-tint: '#005cba'
  primary: '#004e9f'
  on-primary: '#ffffff'
  primary-container: '#0066cc'
  on-primary-container: '#dfe8ff'
  inverse-primary: '#aac7ff'
  secondary: '#705d00'
  on-secondary: '#ffffff'
  secondary-container: '#fcd400'
  on-secondary-container: '#6e5c00'
  tertiary: '#025e16'
  on-tertiary: '#ffffff'
  tertiary-container: '#28772d'
  on-tertiary-container: '#a8fca1'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#d7e3ff'
  primary-fixed-dim: '#aac7ff'
  on-primary-fixed: '#001b3e'
  on-primary-fixed-variant: '#00458e'
  secondary-fixed: '#ffe16d'
  secondary-fixed-dim: '#e9c400'
  on-secondary-fixed: '#221b00'
  on-secondary-fixed-variant: '#544600'
  tertiary-fixed: '#a3f69c'
  tertiary-fixed-dim: '#88d982'
  on-tertiary-fixed: '#002204'
  on-tertiary-fixed-variant: '#005312'
  background: '#f8f9fa'
  on-background: '#191c1d'
  surface-variant: '#e1e3e4'
typography:
  display-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 48px
    fontWeight: '700'
    lineHeight: 56px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
  headline-lg-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 28px
    fontWeight: '700'
    lineHeight: 36px
  headline-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  body-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  label-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  base: 8px
  container-max: 1280px
  gutter: 24px
  margin-mobile: 16px
  margin-desktop: 40px
---

## Brand & Style
The design system is rooted in the identity of Barangay San Isidro, translating its traditional seal into a **Corporate / Modern** digital experience. It is designed to evoke a sense of civic pride, institutional reliability, and community warmth.

The aesthetic prioritizes clarity and accessibility, using high-contrast elements and generous whitespace to ensure information is digestible for a diverse citizenry. It balances the authority of a local government unit with the approachability of a service-oriented community hub. The visual language is structured and dependable, utilizing clean lines and subtle depth to guide users through administrative and community-led digital workflows.

## Colors
The palette is directly extracted from the heritage of the San Isidro seal, optimized for digital accessibility (WCAG 2.1 compliance).

- **Primary (Royal Blue):** Used for primary actions, navigation headers, and authoritative text. It represents stability and professional governance.
- **Secondary (Vibrant Gold):** Primarily used for accents, highlights, and status indicators that require attention. It adds warmth and energy to the interface.
- **Tertiary (Green):** Representing the agricultural and environmental roots of the region, this is used for positive status updates, success messages, and environment-related initiatives.
- **Neutral:** A range of cool grays and whites provide a clean backdrop, ensuring the primary and secondary colors remain impactful without overwhelming the user.

## Typography
**Plus Jakarta Sans** is the sole typeface for this design system, chosen for its modern, geometric construction and high legibility.

The type scale is designed to create a clear information hierarchy. Headlines use a bold weight to establish authority, while body text maintains a generous line height for comfortable reading of long-form community news or official documents. For mobile devices, display and large headline sizes scale down to prevent excessive word-breaking and to maintain a cohesive visual flow.

## Layout & Spacing
This design system utilizes a **Fluid Grid** model based on an 8px spacing rhythm. 

- **Desktop (1024px+):** A 12-column grid with 24px gutters and 40px side margins. 
- **Tablet (768px - 1023px):** An 8-column grid with 20px gutters and 24px side margins.
- **Mobile (Up to 767px):** A 4-column grid with 16px gutters and 16px side margins.

Layouts should favor vertical stacking for readability on mobile and use the 12-column grid on desktop to create balanced asymmetrical compositions for news feeds and service directories.

## Elevation & Depth
The design system employs **Low-contrast outlines** combined with **Tonal layers** to establish hierarchy.

Shadows are used sparingly and should be highly diffused (Large blur, 10-15% opacity) to avoid a heavy, dated look. Depth is primarily achieved by placing white cards on a light-neutral background (`#F8F9FA`). High-priority items, such as active announcements or urgent alerts, may use a thin 1px border in the Primary Blue or Secondary Gold to distinguish themselves from standard content.

## Shapes
A **Rounded** shape language (0.5rem base) is applied across the system. This softens the "institutional" feel of the government website, making it more approachable and modern. 

- **Standard Buttons/Inputs:** 0.5rem (8px)
- **Cards/Containers:** 1rem (16px)
- **Feature Banners:** 1.5rem (24px)
- **Interactive Chips:** Pill-shaped (100px)

This consistency in corner radius creates a unified visual thread that connects navigation, content, and interactive elements.

## Components

### Buttons
- **Primary:** Solid Royal Blue with White text. Used for main calls to action (e.g., "Apply for Permit").
- **Secondary:** Outlined Royal Blue or Solid Gold with High-Contrast text. Used for secondary actions.
- **Tertiary:** Text-only with an icon, used for less prominent navigation.

### Input Fields
Inputs use a white background with a 1px neutral border. Upon focus, the border transitions to Primary Blue with a subtle 2px outer glow. Labels are always positioned above the field for maximum accessibility.

### Cards
Cards are the primary container for community news and service links. They feature a 1px light border and a 16px corner radius. On hover, cards should lift slightly using a soft ambient shadow to indicate interactivity.

### Chips & Badges
Small, pill-shaped elements used for status (e.g., "Approved", "Pending") or categories. Status badges should use the Tertiary Green for success or the Secondary Gold for "action required" states.

### Announcements Bar
A full-width bar at the top of the viewport, utilizing the Secondary Gold background to ensure critical community updates are immediately visible.